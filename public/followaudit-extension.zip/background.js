// FollowAudit 3.1.0: inject the panel into the current Instagram or TikTok tab when the toolbar button is clicked.
const api = globalThis.browser ?? globalThis.chrome;
const SUPPORTED = /^https:\/\/(?:[a-z0-9-]+\.)*(?:instagram|tiktok)\.com\//;

api.action.onClicked.addListener(async (tab) => {
  if (tab.id === undefined || !tab.url || !SUPPORTED.test(tab.url)) {
    await api.tabs.create({ url: 'https://www.instagram.com/' });
    return;
  }
  await api.scripting.executeScript({ target: { tabId: tab.id }, world: 'MAIN', files: ['followaudit.js'] });
});
